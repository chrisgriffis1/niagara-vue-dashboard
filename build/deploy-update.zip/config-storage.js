/* @noSnoop */
/**
 * Config Storage Module
 * Handles loading and saving configuration files using localStorage and file system
 * 
 * PERSISTENCE STRATEGY:
 * Primary: localStorage (works immediately, no setup required, browser-specific)
 * Optional: RPC file creation (requires Java component - see saveConfigFileViaRpc)
 * Fallback: HTTP PUT (only works for existing files)
 */

// ========================================
// FILE LOADING
// ========================================

/**
 * Load a configuration file from the file system
 * @param {string} filePath - Path to the file
 * @param {object} baja - BajaScript reference (passed from main context)
 * @returns {Promise<object|null>} - Parsed JSON config or null
 */
window.loadConfigFile = async function(filePath, baja) {
  console.log('🔍 [DEBUG] loadConfigFile called for:', filePath);
  try {
    // Normalize file path
    let normalizedPath = filePath;
    if (!normalizedPath.startsWith('files/')) {
      console.log('💡 File path is relative to HTML file directory:', normalizedPath);
    } else {
      normalizedPath = normalizedPath.substring(6);
    }
    const fileOrd = 'file:^' + normalizedPath;
    console.log('🔍 [DEBUG] Attempting to load file with ORD:', fileOrd);
    
    let file;
    try {
      file = await baja.Ord.make(fileOrd).get();
      console.log('🔍 [DEBUG] File object retrieved:', file ? 'success' : 'null');
    } catch (ordError) {
      console.log('🔍 [DEBUG] File does not exist (expected on first run):', fileOrd);
      return null;
    }
    
    if (!file || file.isDirectory()) {
      console.log('🔍 [DEBUG] File is null or is a directory');
      return null;
    }
    
    const readUri = file.getReadUri();
    if (!readUri) {
      return null;
    }
    
    const res = await fetch(readUri);
    if (!res.ok) {
      console.log('🔍 [DEBUG] Fetch failed with status:', res.status);
      return null;
    }
    
    const text = await res.text();
    const config = JSON.parse(text);
    console.log('✅ Config loaded from file:', filePath);
    return config;
  } catch (err) {
    console.log('🔍 [DEBUG] loadConfigFile error (expected):', err.name, err.message);
    return null;
  }
};

// ========================================
// RPC-BASED FILE SAVING
// ========================================

/**
 * Save configuration file via RPC (requires Java component)
 * @param {string} filePath - Path to the file
 * @param {object} data - Data to save
 * @param {object} baja - BajaScript reference
 * @returns {Promise<boolean>} - Success status
 */
window.saveConfigFileViaRpc = async function(filePath, data, baja) {
  try {
    let normalizedPath = filePath;
    if (normalizedPath.startsWith('files/')) {
      normalizedPath = normalizedPath.substring(6);
    }
    
    // Try to find a file service component
    const possibleServiceOrds = [
      'station:|slot:/Services/FileService',
      'station:|slot:/Services/DashboardFileService',
      'station:|slot:/FileService',
      'station:|slot:/Services/ConfigService'
    ];
    
    for (const serviceOrd of possibleServiceOrds) {
      try {
        const service = await baja.Ord.make(serviceOrd).get();
        if (service) {
          console.log('🔍 [DEBUG] Found file service, attempting RPC write:', serviceOrd);
          await service.rpc('writeFile', normalizedPath, JSON.stringify(data, null, 2));
          console.log('✅ Config saved via RPC to:', filePath);
          return true;
        }
      } catch (e) {
        continue;
      }
    }
    
    // Try HTTP RPC servlet approach
    console.log('🔍 [DEBUG] No file service component found, trying HTTP RPC servlet...');
    
    const rpcServiceOrds = [
      'type:web:FileService',
      'station:|slot:/Services/FileService',
      'station:|slot:/Services/DashboardFileService'
    ];
    
    for (const rpcOrd of rpcServiceOrds) {
      try {
        let csrfToken = '';
        try {
          const csrfMeta = document.querySelector('meta[name="csrf-token"]');
          if (csrfMeta) {
            csrfToken = csrfMeta.getAttribute('content');
          } else if (window.csrfToken) {
            csrfToken = window.csrfToken;
          }
        } catch (e) {}
        
        const rpcUrl = '/rpc/writeFile/' + encodeURIComponent(rpcOrd);
        const headers = { 'Content-Type': 'application/json' };
        if (csrfToken) {
          headers['x-niagara-csrfToken'] = csrfToken;
        }
        
        const rpcRes = await fetch(rpcUrl, {
          method: 'POST',
          headers: headers,
          body: JSON.stringify([normalizedPath, JSON.stringify(data, null, 2)])
        });
        
        if (rpcRes.ok) {
          console.log('✅ Config saved via HTTP RPC servlet to:', filePath);
          return true;
        }
      } catch (e) {
        continue;
      }
    }
    
    return false;
  } catch (err) {
    console.log('🔍 [DEBUG] RPC file creation failed:', err.message);
    return false;
  }
};

// ========================================
// MAIN SAVE FUNCTION
// ========================================

/**
 * Save configuration file (localStorage primary, file system optional)
 * @param {string} filePath - Path to the file
 * @param {object} data - Data to save
 * @param {object} baja - BajaScript reference
 * @returns {Promise<boolean>} - Success status
 */
window.saveConfigFile = async function(filePath, data, baja) {
  try {
    // PRIMARY: Use localStorage (works immediately, no setup needed)
    try {
      const storageKey = 'dashboard_config_' + filePath.replace(/[^a-zA-Z0-9]/g, '_');
      localStorage.setItem(storageKey, JSON.stringify(data, null, 2));
      console.log('✅ Config saved to localStorage:', storageKey);
      return true;
    } catch (storageErr) {
      console.warn('⚠️ localStorage save failed:', storageErr);
    }
    
    // OPTIONAL: Try RPC-based file creation
    if (baja) {
      console.log('🔍 [DEBUG] Attempting RPC-based file creation (optional)...');
      const rpcResult = await window.saveConfigFileViaRpc(filePath, data, baja);
      if (rpcResult) {
        console.log('✅ Also saved via RPC (file system)');
        return true;
      }
      
      // Try direct file write
      console.log('🔍 [DEBUG] Attempting direct file write (optional)...');
      let normalizedPath = filePath;
      if (!normalizedPath.startsWith('files/')) {
        console.log('💡 File path is relative to HTML file directory:', normalizedPath);
      } else {
        normalizedPath = normalizedPath.substring(6);
      }
      
      const fileOrd = 'file:^' + normalizedPath;
      
      // Ensure directory exists
      const dirPath = normalizedPath.substring(0, normalizedPath.lastIndexOf('/'));
      if (dirPath) {
        await window.ensureDirectoryExists(dirPath, baja);
      }
      
      // Try to get write URI
      let file;
      try {
        file = await baja.Ord.make(fileOrd).get();
      } catch (e) {
        console.log('💡 File does not exist yet, will create:', fileOrd);
        file = null;
      }
      
      let writeUri = file ? file.getWriteUri() : '/ord/file:^' + normalizedPath;
      
      if (writeUri) {
        console.log('🔍 [DEBUG] Attempting PUT to:', writeUri);
        const res = await fetch(writeUri, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data, null, 2)
        });
        
        if (res.ok) {
          console.log('✅ Also saved to file system:', filePath);
          return true;
        }
      }
    }
    
    // localStorage already saved above
    return true;
  } catch (err) {
    console.warn('⚠️ Error in saveConfigFile:', filePath, err.message);
    // Try localStorage as final fallback
    try {
      const storageKey = 'dashboard_config_' + filePath.replace(/[^a-zA-Z0-9]/g, '_');
      localStorage.setItem(storageKey, JSON.stringify(data, null, 2));
      console.log('✅ Config saved to localStorage (fallback):', storageKey);
      return true;
    } catch (storageErr) {
      console.warn('⚠️ All save methods failed:', storageErr);
      return false;
    }
  }
};

// ========================================
// DIRECTORY UTILITIES
// ========================================

/**
 * Ensure a directory exists (creates parent directories as needed)
 * @param {string} dirPath - Path to the directory
 * @param {object} baja - BajaScript reference
 * @returns {Promise<boolean>} - Success status
 */
window.ensureDirectoryExists = async function(dirPath, baja) {
  try {
    let normalizedPath = dirPath;
    if (normalizedPath.startsWith('files/')) {
      normalizedPath = normalizedPath.substring(6);
    }
    const dirOrd = 'file:^' + normalizedPath;
    
    try {
      const dir = await baja.Ord.make(dirOrd).get();
      if (dir && dir.isDirectory()) {
        return true;
      }
    } catch (e) {
      // Directory doesn't exist
    }
    
    // Try to create parent directory first
    const parentPath = normalizedPath.substring(0, normalizedPath.lastIndexOf('/'));
    if (parentPath) {
      await window.ensureDirectoryExists(parentPath, baja);
    }
    
    console.log('💡 Directory will be created when file is written:', dirPath);
    return true;
  } catch (err) {
    console.warn('⚠️ Error ensuring directory exists:', dirPath, err.message);
    return false;
  }
};

// ========================================
// DEFAULT CONFIG
// ========================================

/**
 * Get default configuration object
 * @returns {object} - Default config
 */
window.getDefaultConfig = function() {
  return {
    "global": {
      "rules": [
        {"pattern": ".*hp.*|.*heat.?pump.*|.*heater.*|.*htr.*", "type": "heatpump", "icon": "heatpump.svg"},
        {"pattern": ".*exh.*fan.*|.*exfan.*|.*ef\\d.*", "type": "exhaustfan", "icon": "fan.svg"},
        {"pattern": ".*boiler.*|.*blr.*", "type": "boiler", "icon": "boiler.svg"},
        {"pattern": ".*genset.*|.*generator.*", "type": "generator", "icon": "generator.svg"},
        {"pattern": ".*charger.*|.*battery.*", "type": "charger", "icon": "battery.svg"},
        {"pattern": ".*cooling.*tower.*|.*tower.*plant.*", "type": "coolingtower", "icon": "tower.svg"},
        {"pattern": ".*pump.*|.*clp.*|.*ctp.*", "type": "pump", "icon": "pump.svg"},
        {"pattern": ".*freezer.*|.*frzr.*|.*fridge.*|.*walk.?in.*", "type": "freezer", "icon": "freezer.svg"},
        {"pattern": ".*ahu.*|.*air.?handler.*|.*rtu.*", "type": "ahu", "icon": "ahu.svg"},
        {"pattern": ".*mau.*|.*make.?up.*", "type": "mau", "icon": "mau.svg"},
        {"pattern": ".*vav.*|.*zone.?box.*|.*terminal.*", "type": "vav", "icon": "vav.svg"},
        {"pattern": ".*kitchen.*|.*hood.*|.*cooking.*", "type": "kitchen", "icon": "kitchen.svg"}
      ],
      "zones": [],
      "groups": {},
      "snapshot": null,
      "lastSync": null,
      "syncMode": "manual"
    },
    "users": {},
    "presets": {},
    "dashboardAssignments": {}
  };
};

// ========================================
// HIGH-LEVEL CONFIG API
// ========================================

/**
 * Load the main dashboard configuration
 * @param {object} baja - BajaScript reference
 * @returns {Promise<object>} - Config object
 */
window.loadDashboardConfig = async function(baja) {
  console.log('🔍 [DEBUG] loadDashboardConfig() called');
  try {
    // PRIMARY: Try localStorage first
    try {
      const storageKey = 'dashboard_config_files_dashboard_config_json';
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        console.log('✅ Global config loaded from localStorage');
        return parsed;
      }
    } catch (storageErr) {
      console.log('🔍 [DEBUG] No localStorage config found');
    }
    
    // OPTIONAL: Try file system
    if (baja) {
      // Try same directory as HTML
      console.log('🔍 [DEBUG] Attempting to load from same directory as HTML file...');
      const sameDirConfig = await window.loadConfigFile('dashboard-config.json', baja);
      if (sameDirConfig) {
        console.log('✅ Global config loaded from same directory as HTML file');
        if (!sameDirConfig.dashboardAssignments) {
          sameDirConfig.dashboardAssignments = {};
        }
        // Cache to localStorage
        try {
          const storageKey = 'dashboard_config_files_dashboard_config_json';
          localStorage.setItem(storageKey, JSON.stringify(sameDirConfig, null, 2));
        } catch (e) {}
        return sameDirConfig;
      }
      
      // Try standard location
      console.log('🔍 [DEBUG] Attempting to load from standard location...');
      const globalConfig = await window.loadConfigFile('files/dashboard/config.json', baja);
      if (globalConfig) {
        console.log('✅ Global config loaded from file system');
        try {
          const storageKey = 'dashboard_config_files_dashboard_config_json';
          localStorage.setItem(storageKey, JSON.stringify(globalConfig, null, 2));
        } catch (e) {}
        return globalConfig;
      }
    }
    
    // No config found - create default
    console.log('🔍 [DEBUG] Creating default config...');
    const defaultConfig = window.getDefaultConfig();
    if (!defaultConfig.dashboardAssignments) {
      defaultConfig.dashboardAssignments = {};
    }
    
    // Save to localStorage and optionally file system
    await window.saveConfigFile('dashboard-config.json', defaultConfig, baja);
    
    return defaultConfig;
  } catch (err) {
    console.warn('⚠️ Error loading config:', err.message);
    return window.getDefaultConfig();
  }
};

/**
 * Save the main dashboard configuration
 * @param {object} config - Config object to save
 * @param {object} baja - BajaScript reference
 * @returns {Promise<boolean>} - Success status
 */
window.saveDashboardConfig = async function(config, baja) {
  try {
    const saved = await window.saveConfigFile('files/dashboard/config.json', config, baja);
    if (!saved) {
      console.warn('⚠️ Failed to save config to file system');
    }
    return saved;
  } catch (err) {
    console.warn('⚠️ Error saving config:', err.message);
    return false;
  }
};

console.log('✅ config-storage.js loaded');

