/* @noSnoop */
if('serviceWorker' in navigator) {window.addEventListener('load', () => {navigator.serviceWorker.register('/file/web1/sw.js', { scope: '/file/web1/' })})}